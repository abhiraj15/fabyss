<?php
App::uses('AppModel', 'Model');
/**
 * Post Model
 *
 * @property User $User
 */
class Comment extends AppModel {
/**
 * Validation rules
 *
 * @var array
 */
 	public $name = 'Comment';
    public $useTable = "comments";
	public $validate = array(
		'comment' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Your custom message here',
				'allowEmpty' => false,
				'required' => true,
				'last' => false, // Stop validation after this rule
				'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);

	//The Associations below have been created with all possible keys, those that are not needed can be removed

}

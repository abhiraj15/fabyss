<?php
App::uses('AppModel', 'Model');


/**
 * Group Model
 *
 * @property Group $Group
 */
class Contact extends AppModel {
    public $name = 'Contact';
    public $useTable = "contacts";   
}

<?php
App::uses('AppModel', 'Model');


/**
 * Group Model
 *
 * @property Group $Group
 */
class Group extends AppModel {
    public $name = 'Group';
    public $useTable = "groups";
    public $validate = array(
        'name' => array(
            'notEmpty' => array('rule' => 'notEmpty', 'message' => 'Group name can not be empty.'),
            'unique' => array('rule' => 'isUnique','message' => 'Group name already in use.')
        )
    );

    function parentNode() {
        return null;
    }
}

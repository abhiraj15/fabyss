<?php
App::uses('AppModel', 'Model');
/**
 * Post Model
 *
 * @property User $User
 */
class Post extends AppModel {
/**
 * Validation rules
 *
 * @var array
 */
 
	public $name = 'Post';
    public $useTable = "posts";
	public $validate = array(
		'title' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'You must be enter titie',
				'allowEmpty' => false,
				'required' => true,
				'last' => false, // Stop validation after this rule
				'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
			'minlength' => array(
                'rule' => array('minLength', '10'),
                'message' => 'Minimum length of 10 characters.'
            ),
		),
		'content' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'You must be enter content',
				'allowEmpty' => false,
				'required' => true,
				'last' => false, // Stop validation after this rule
				'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
			'minlength' => array(
                'rule' => array('minLength', '100'),
                'message' => 'Minimum length of 100 characters.'
            ),
		)
		
	);


}

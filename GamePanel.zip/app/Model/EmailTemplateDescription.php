<?php
App::uses('AppModel', 'Model');


/**
 * Group Model
 *
 * @property Group $Group
 */
class EmailTemplateDescription extends AppModel {
    public $name = 'EmailTemplateDescription';
    public $useTable = "email_template_descriptions";
  
      public $validate = array(
        'subject' => array(
            'required' => true,
            'allowEmpty' => false,
            'rule' => 'notEmpty',
            'message' => 'You must enter your real Subject.'
        ),
        'email_template_id' => array(
            'required' => true,
            'allowEmpty' => false,
            'rule' => 'notEmpty',
            'message' => 'You must select Template.'
        )
    );
  
	
   
}

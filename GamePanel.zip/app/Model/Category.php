<?php
App::uses('AppModel', 'Model');
/**
 * Category Model
 *
 * @property User $User
 */
class Category extends AppModel {	
	/**
	 * Validation rules
	 *
	 * @var array
	 */
	public $name = 'Category';
	public $useTable = "categories";
	public $actsAs = array('Tree');
	public $validate = array(
			'name' => array(
				'notempty' => array(
					'rule' => array('notempty'),
					//'message' => 'Your custom message here',
					//'allowEmpty' => false,
					//'required' => false,
					//'last' => false, // Stop validation after this rule
					//'on' => 'create', // Limit validation to 'create' or 'update' operations
				),
			),
		);
		
	public function beforeSave($data=array()) {
	
	 $this->data['Category']['name']=trim($this->data['Category']['name']);
	 
	}

}
?>
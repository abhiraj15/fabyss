<?php
App::uses('AppModel', 'Model');


/**
 * User Model
 */
class EmailTemplate extends AppModel {
    public $name = 'EmailTemplate';
    public $useTable = "email_templates";
	public $validate = array(
        'title' => array(
            'notEmpty' => array('rule' => 'notEmpty', 'message' => 'Title can not be empty.'),
            'unique' => array('rule' => 'isUnique','message' => 'Title already in use.')
        )
    );

}
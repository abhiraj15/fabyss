<?php
App::uses('AppModel', 'Model');


/**
 * Group Model
 *
 * @property Group $Group
 */
class NewsLetter extends AppModel {
    public $name = 'NewsLetter';
    public $useTable = "news_letters"; 
	public $validate = array(
        'title' => array(
            'notEmpty' => array('rule' => 'notEmpty', 'message' => 'Title can not be empty.'),
            'unique' => array('rule' => 'isUnique','message' => 'Title already in use.')
        ),'subject' => array(
            'required' => true,
            'allowEmpty' => false,
            'rule' => 'notEmpty',
            'message' => 'You must enter your real Subject.'
        )
    );
	
	
	
}

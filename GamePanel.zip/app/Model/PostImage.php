<?php
App::uses('AppModel', 'Model');
/**
 * Post Model
 *
 * @property User $User
 */
class PostImage extends AppModel {
/**
 * Validation rules
 *
 * @var array
 */
 	public $name = 'PostImage';
    public $useTable = "post_images";
	public $validate = array(
		'comment' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Your custom message here',
				'allowEmpty' => false,
				'required' => true,
				'last' => false, // Stop validation after this rule
				'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);

}

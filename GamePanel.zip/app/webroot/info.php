<?php
echo phpinfo();

 ?>
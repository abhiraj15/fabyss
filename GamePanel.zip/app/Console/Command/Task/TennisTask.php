<?php
/**
 * AppShell file
 *
 * PHP 5
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright 2005-2012, Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright 2005-2012, Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @since         CakePHP(tm) v 2.0
 * @license       MIT License (http://www.opensource.org/licenses/mit-license.php)
 */



/**
 * Application Shell
 *
 * Add your application-wide methods in the class below, your shells
 * will inherit them.
 *
 * @package       app.Console.Command
 */
App::import('Component', 'Datascraping'); 
App::uses('Datascraping');

class TennisTask extends Shell {
	
	var $uses = array('Tennis');

	public function scrap() {
		
		$datas=$this->Datascraping->TennisScraping();	
		$i=0;
		foreach($datas->Tennis as $data_value){
		
			$this->request->data['Tennis'][$i]['tournament']=$data_value->tournament;
			$this->request->data['Tennis'][$i]['match_date']=date("Y-m-d",strtotime($data_value->match_date));
			$this->request->data['Tennis'][$i]['match_time']=$data_value->match_time;
			$this->request->data['Tennis'][$i]['player_1']=$data_value->player_1;
			$this->request->data['Tennis'][$i]['player_2']=$data_value->player_2;					
			$this->request->data['Tennis'][$i]['player_3']=$data_value->player_3;
			$this->request->data['Tennis'][$i]['player_4']=$data_value->player_4;
			$this->request->data['Tennis'][$i]['created']=date("Y-m-d H:i:s");
			$this->request->data['Tennis'][$i]['status']=1;
			$i++;
		}
		
		$this->Tennis->saveAll($this->request->data['Tennis']);
		
		
	}
		
		
}

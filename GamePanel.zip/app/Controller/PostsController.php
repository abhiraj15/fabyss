<?php
	/**
	 * Static content controller.
	 *
	 * This file will render views from views/pages/
	 *
	 * PHP 5
	 *
	 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
	 * Copyright 2005-2012, Cake Software Foundation, Inc. (http://cakefoundation.org)
	 *
	 * Licensed under The MIT License
	 * Redistributions of files must retain the above copyright notice.
	 *
	 * @copyright     Copyright 2005-2012, Cake Software Foundation, Inc. (http://cakefoundation.org)
	 * @link          http://cakephp.org CakePHP(tm) Project
	 * @package       app.Controller
	 * @since         CakePHP(tm) v 0.2.9
	 * @license       MIT License (http://www.opensource.org/licenses/mit-license.php)
	 */

App::uses('AppController', 'Controller');

	/**
	 * Static content controller
	 *
	 * Override this controller by placing a copy in controllers directory of an application
	 *
	 * @package       app.Controller
	 * @link http://book.cakephp.org/2.0/en/controllers/pages-controller.html
	 */
	class PostsController extends AppController {

	/**
	* Controller name
	*
	* @var string
	*/
	
	public $name = 'Posts';
	
	/**
	* This controller does not use a model
	*
	* @var array
	*/
	
	public $uses = array('Post','Comment');

	 function beforeFilter() {
		 
		parent::beforeFilter();	
			
		 $this->Post->bindModel(array('belongsTo'=>array(
			'Category' => array(
				'className' => 'Category',
				'foreignKey' => 'category_id',
				'dependent'=>true
			),'User' => array(
				'className' => 'User',
				'foreignKey' => 'user_id',
				'dependent'=>true
			)
		)), false);
		  
		$this->Comment->bindModel(array('belongsTo'=>array(
		   'Post' => array(
				'className' => 'Post',
				'foreignKey' => 'post_id',
				'dependent'=>true
			),'User' => array(
				'className' => 'User',
				'foreignKey' => 'user_id',
				'dependent'=>true
			)
		  )), false);  
		  
			
	}

	/**
	* index method
	*
	* @param string $id
	* @return void
	*/
	
	public function admin_index(){
		
		$this->layout = "admin_dashboard";	
		
		$this->paginate = array('order'=>array('Post.id' => 'DESC'));

		$this->Post->recursive = 1;
		
		$this->set('posts', $this->paginate());
		
			 	
	}
	
	
	 /**
     * add method
     *
     * @return void
     */

	
	  public function admin_add() {		
			$this->layout = "admin_form";		
			if ($this->request->is('post')) {
				$this->Post->create();
				if ($this->Post->save($this->request->data)) {
					$this->Session->setFlash(__('The Post has been saved'), 'admin_success');
					$this->redirect(array('action' => 'index'));
				} else {
					$this->Session->setFlash(__('The Post could not be saved. Please, try again.'), 'admin_error');
				}
			}
			$categories = $this->Post->Category->find('list');
			$this->set(compact('categories'));
	 }
	
	
	 /**
     * edit method
     *
     * @param string $id
     * @return void
     */

	
	  public function admin_edit($id = null) {		
		$this->layout = "admin_form";		
        $this->Post->id = $id;
        if (!$this->Post->exists()) {
            throw new NotFoundException(__('Invalid Post'));
        }
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->Post->save($this->request->data)) {
                $this->Session->setFlash(__('The Post has been saved'), 'admin_success');
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The Post could not be saved. Please, try again.'), 'admin_error');
            }
        } else {
            $this->request->data = $this->Post->read(null, $id);
        }
		
        $categories = $this->Post->Category->find('list');
		$this->set(compact('categories'));
    }
	
	
	/**
     * delete method
     *
     * @param string $id
     * @return void
     */

	public function admin_delete($id = null) {
        if (!$this->request->is('post')) {
            throw new MethodNotAllowedException();
        }
		
        $this->Post->id = $id;
        if (!$this->Post->exists()) {
            throw new NotFoundException(__('Invalid Post'));
        }
		
        if ($this->Post->delete()) {
            $this->Session->setFlash(__('Post deleted'), 'admin_success');
            $this->redirect(array('action' => 'index'));
        }
		
        $this->Session->setFlash(__('Post was not deleted'), 'admin_error');
        $this->redirect(array('action' => 'index'));
    }
	
	
	
	/**
	 *  Active/Inactive Post
	 *
	 * @param <int> $Post_id
	 */
	 public function admin_toggle($post_id, $status) {
			$this->layout = "ajax";
			$status = ($status) ? 0 : 1;
			$this->set(compact('post_id', 'status'));
			if ($Post_id) {
				$data['Post'] = array('id'=>$post_id, 'status'=>$status);
				$allowed = $this->Post->saveAll($data["Post"], array('validate'=>false));           
			} 
	  }

	/**
	 *  Active/Inactive Post Comments
	 *
	 * @param <int> $Post_id
	 */
	
	public function admin_comments(){
		
		$this->layout = "admin_dashboard";	
		
		$this->paginate = array('order'=>array('Comment.id' => 'DESC'));

		$this->Comment->recursive = 1;
		
		$this->set('comments', $this->paginate());
		
			 	
	}
	


	
	
	
		 
	 

}

<?php
App::uses('AppController', 'Controller');
/**
 * Contacts Controller
 *
 * @property Contact $Contact
 */
class ContactsController extends AppController {

    public function beforeFilter() {
        parent::beforeFilter();  		     
        $this->layout = "admin_dashboard";    
	}
/**
 * home method
 *
 * @return void
 */
	public function admin_index() {
        $this->set('title', __('Contacts')); 
		$this->paginate = array('order'=>array('Contact.created' => 'DESC'));
		$this->Contact->recursive = 0;
		$this->set('contacts', $this->paginate());
	}
	


/**
 * view method
 *
 * @param string $id
 * @return void
 */
	public function admin_view($id = null) {
		$this->layout = "ajax"; 
		$this->Contact->id = $id;		
		if (!$this->Contact->exists()) {
			throw new NotFoundException(__('Invalid post'));
		}
		
		$this->set('contact', $this->Contact->read(null, $id));
	}


/**
 * delete method
 *
 * @param string $id
 * @return void
 */
	public function admin_delete($id = null) {
		
		if (!$this->request->is('post')) {
			throw new MethodNotAllowedException();
		}
		
		$this->Contact->id = $id;
		if (!$this->Contact->exists()) {
			throw new NotFoundException(__('Invalid post'), 'admin_error');
		}
		if ($this->Contact->delete()) {
			$this->Session->setFlash(__('Contact deleted'), 'admin_error');
			$this->redirect(array('action' => 'admin_index'));
		}
		$this->Session->setFlash(__('Contact was not deleted'), 'admin_success');
		$this->redirect(array('action' => 'admin_index'));
	}
}

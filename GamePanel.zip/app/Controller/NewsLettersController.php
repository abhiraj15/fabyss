<?php
App::uses('AppController', 'Controller');

 /**
 * NewsLetters Controller
 *
 * @property NewsLetter $NewsLetter
 */
 
class NewsLettersController extends AppController {

	public $uses = array('NewsLetter');
    public function beforeFilter() {
        parent::beforeFilter(); 
	}
/**
 * home method
 *
 * @return void
 */
	public function admin_index() {
		$this->layout = "admin_table";
		$this->paginate = array('order'=>array('NewsLetter.id' => 'DESC'));
		$this->NewsLetter->recursive = 0;
		$this->set('templates', $this->paginate());
	}
	


/**
 * view method
 *
 * @param string $id
 * @return void
 */
	public function admin_view($id = null) {
		 $this->layout = "ajax";
		$this->NewsLetter->id = $id;		
		if (!$this->NewsLetter->exists()) {
			throw new NotFoundException(__('Invalid template'));
		}
		
		$this->set('template', $this->NewsLetter->read(null, $id));
	}

/**
 * add method
 *
 * @return void
 */
	public function admin_add() {	
		$this->layout = "admin_form";   		
		if ($this->request->is('post')) {
			$this->loadModel('NewsLetter');			
			$this->NewsLetter->create();			
			if ($this->NewsLetter->save($this->request->data,array('validate' => 'only'))) {
				$this->Session->setFlash(__('The template has been saved'), 'admin_success');
				$this->redirect(array('action' => 'admin_index'));
			} else {
				$this->Session->setFlash(__('The template could not be saved. Please, try again.'), 'admin_error');
			}
		}
	
	}

/**
 * edit method
 *
 * @param string $id
 * @return void
 */
	public function admin_edit($id = null) {
		$this->layout = "admin_form";   	
			
		$this->NewsLetter->id = $id;
		if (!$this->NewsLetter->exists()) {
			throw new NotFoundException(__('Invalid template'));
		}
		
		if ($this->request->is('post') || $this->request->is('put')) {
			
			if ($this->NewsLetter->save($this->request->data,array('validate' => 'only'))) {
				$this->Session->setFlash(__('The template has been saved'), 'admin_success');
				$this->redirect(array('action' => 'admin_index'));
			} else {
				$this->Session->setFlash(__('The template could not be saved. Please, try again.'), 'admin_error');
			}
		} else {
			$this->request->data = $this->NewsLetter->read(null, $id);
			
		}
	}

/**
 * delete method
 *
 * @param string $id
 * @return void
 */
	public function admin_delete($id = null) {
		
		if (!$this->request->is('post')) {
			throw new MethodNotAllowedException();
		}
		
		$this->NewsLetter->id = $id;
		if (!$this->NewsLetter->exists()) {
			throw new NotFoundException(__('Invalid template'), 'admin_error');
		}
		if ($this->NewsLetter->delete()) {
			$this->Session->setFlash(__('NewsLetter deleted'), 'admin_success');
			$this->redirect(array('action' => 'admin_index'));
		}
		$this->Session->setFlash(__('NewsLetter was not deleted'), 'admin_error');
		$this->redirect(array('action' => 'admin_index'));
	}
	
 	/**
     *  Active/Inactive Templates
     *
     * @param <int> 
     */
    public function toggle($temp_id, $status) {
        $this->layout = "ajax";
        $status = ($status) ? 0 : 1;
        $this->set(compact('temp_id', 'status'));
        if ($temp_id) {
            $data['NewsLetter'] = array('id'=>$temp_id, 'status'=>$status);
            $allowed = $this->NewsLetter->saveAll($data["NewsLetter"], array('validate'=>false));           
        } 
    }	
	
	
}

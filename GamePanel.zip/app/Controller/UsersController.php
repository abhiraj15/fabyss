<?php
App::uses('AppController', 'Controller');


/**
 * Users Controller
 *
 * @property User $User
 */
class UsersController extends AppController {
    
   public $uses = array('User','EmailTemplateDescription');
   public $paginate = array('limit' => 100);
   
   function beforeFilter() {
	   
	   
        parent::beforeFilter();
        $this->layout = "admin_dashboard";

        $this->Auth->allow('admin_login');
        $this->User->bindModel(array('belongsTo'=>array(
            'Group' => array(
                'className' => 'Group',
                'foreignKey' => 'group_id',
                'dependent'=>true
            )
        )
        ), false);
		
	  
		
    }
	
	
	
    /**
     * Temp acl init db
     */
//    function initDB() {
//        $this->autoRender = false;
//
//        $group = $this->User->Group;
//        //Allow admins to everything
//        $group->id = 1;
//        $this->Acl->allow($group, 'controllers');
//
//        //allow managers to posts and widgets
//        $group->id = 2;
//        $this->Acl->deny($group, 'controllers');
//        //$this->Acl->allow($group, 'controllers/Posts'); //allow all action of controller posts
//        $this->Acl->allow($group, 'controllers/Posts/add');
//        $this->Acl->deny($group, 'controllers/Posts/edit');
//
//        //we add an exit to avoid an ugly "missing views" error message
//        echo "all done";
//        exit;
//    }




    /**
     * login method
     *
     * @return void
     */
	 
		function admin_login() {
		    $this->layout = "admin_login";

			if ($this->Auth->user()) {

			  $this->redirect(array('action' => 'admin_index'));
			  			
			}else if ($this->request->is('post')) {
				
				if ($this->Auth->login()) {
					$this->redirect($this->Auth->redirect());
				} else {
					$this->Session->setFlash('Your username or password was incorrect.', 'admin_error');
				}
					
			}
		}
	
	
    /**
     * logout method
     *
     * @return void
     */
  
	function admin_logout() {
        $this->Session->setFlash('Good-Bye', 'success');
        $this->redirect($this->Auth->logout());
    }
	
    /**
     * index method
     *
     * @return void
     */
	
	 public function admin_index() {
		 
        $this->layout = "admin_table";        
        $this->User->recursive = 1;
        $this->set('users', $this->paginate("User",array('NOT'=>array('User.id' => $this->Auth->user('id')))));       
     }
	
	
    /**
     * view method
     *
     * @param string $id
     * @return void
     */
	 
	 
 
 	 public function admin_view($id = null) {
		$this->layout = "ajax";		
        $this->set('title', __('View'));
        $this->User->id = $id;
        if (!$this->User->exists()) {
            throw new NotFoundException(__('Invalid user'), 'error');
        }
        $this->set('user', $this->User->read(null, $id));
     }
	 
    /**
     * add method
     *
     * @return void
     */

	
	public function admin_add() {		
		$this->layout = "admin_form";		
        if ($this->request->is('post')) {
            $this->User->create();
            if ($this->User->save($this->request->data)) {
                $this->Session->setFlash(__('The user has been saved'), 'admin_success');
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The user could not be saved. Please, try again.'), 'admin_error');
            }
        }
        $groups = $this->User->Group->find('list');
        $this->set(compact('groups'));
    }

    /**
     * edit method
     *
     * @param string $id
     * @return void
     */

	
	  public function admin_edit($id = null) {		
		$this->layout = "admin_form";		
        $this->User->id = $id;
        if (!$this->User->exists()) {
            throw new NotFoundException(__('Invalid user'));
        }
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->User->save($this->request->data)) {
                $this->Session->setFlash(__('The user has been saved'), 'admin_success');
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The user could not be saved. Please, try again.'), 'admin_error');
            }
        } else {
            $this->request->data = $this->User->read(null, $id);
            $this->request->data['User']['password'] = null;
        }
        $groups = $this->User->Group->find('list');
        $this->set(compact('groups'));
    }
	
	

    /**
     * delete method
     *
     * @param string $id
     * @return void
     */

	public function admin_delete($id = null) {
        if (!$this->request->is('post')) {
            throw new MethodNotAllowedException();
        }
        $this->User->id = $id;
        if (!$this->User->exists()) {
            throw new NotFoundException(__('Invalid user'));
        }
        if ($this->User->delete()) {
            $this->Session->setFlash(__('User deleted'), 'admin_success');
            $this->redirect(array('action' => 'index'));
        }
        $this->Session->setFlash(__('User was not deleted'), 'admin_error');
        $this->redirect(array('action' => 'index'));
    }


    /**
     *  Active/Inactive User
     *
     * @param <int> $user_id
     */
		public function toggle($user_id, $status) {
			$this->layout = "ajax";
			$status = ($status) ? 0 : 1;
			$this->set(compact('user_id', 'status'));
			if ($user_id) {
				$data['User'] = array('id'=>$user_id, 'status'=>$status);
				$allowed = $this->User->saveAll($data["User"], array('validate'=>false));           
			} 
		}
     
	 
	
	

	 
	 
	
}
?>
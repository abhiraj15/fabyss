<?php
	/**
	 * Static content controller.
	 *
	 * This file will render views from views/pages/
	 *
	 * PHP 5
	 *
	 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
	 * Copyright 2005-2012, Cake Software Foundation, Inc. (http://cakefoundation.org)
	 *
	 * Licensed under The MIT License
	 * Redistributions of files must retain the above copyright notice.
	 *
	 * @copyright     Copyright 2005-2012, Cake Software Foundation, Inc. (http://cakefoundation.org)
	 * @link          http://cakephp.org CakePHP(tm) Project
	 * @package       app.Controller
	 * @since         CakePHP(tm) v 0.2.9
	 * @license       MIT License (http://www.opensource.org/licenses/mit-license.php)
	 */

App::uses('AppController', 'Controller');

	/**
	 * Static content controller
	 *
	 * Override this controller by placing a copy in controllers directory of an application
	 *
	 * @package       app.Controller
	 * @link http://book.cakephp.org/2.0/en/controllers/pages-controller.html
	 */
	class PagesController extends AppController {

	/**
	* Controller name
	*
	* @var string
	*/
	
	public $name = 'Pages';
	
	/**
	* This controller does not use a model
	*
	* @var array
	*/
	
	public $uses = array('Page','User','Setting');

	 function beforeFilter() {
		   
		   
			parent::beforeFilter();
			
			
			$this->Setting->bindModel(array('belongsTo'=>array(
				'Category' => array(
					'className' => 'Category',
					'foreignKey' => 'category_id',
					'dependent'=>true
				)
			)), false);
			
		}

	/**
	* index method
	*
	* @param string $id
	* @return void
	*/
	
	public function admin_index(){
	$this->layout = "admin_dashboard";
	/*$chatgroups=$this->ChatGroup->find("all");
	echo "<pre>";
	print_r($chatgroups);
	echo "</pre>";*/
		 	
	}


	/**
	* edit method
	*
	* @param string $id
	* @return void
	*/

	public function admin_terms_conditions($id = null) {
		$this->layout = "admin_dashboard"; 
		$this->Page->id = $id;
		if (!$this->Page->exists()) {
			throw new NotFoundException(__('Invalid post'));
		}
		
		if ($this->request->is('post') || $this->request->is('put')) {
			
			if ($this->Page->save($this->request->data)) {
				$this->Session->setFlash(__('Terms & Conditions has been saved'), 'admin_success');
				$this->redirect(array('action' => 'admin_terms_conditions',$id));
			} else {
				$this->Session->setFlash(__('Terms & Conditions could not be saved. Please, try again.'), 'admin_error');
			}
		} else {
			$this->request->data = $this->Page->read(null, $id);
		}
		
	}
	
	/**
	* edit method
	*
	* @param string $id
	* @return void
	*/
	
	public function admin_privacy_policy($id = null) {
		$this->layout = "admin_dashboard"; 
		$this->Page->id = $id;
		if (!$this->Page->exists()) {
			throw new NotFoundException(__('Invalid post'));
		}
		
		if ($this->request->is('post') || $this->request->is('put')) {
			
			if ($this->Page->save($this->request->data)) {
				$this->Session->setFlash(__('Privacy Policy has been saved'), 'admin_success');
				$this->redirect(array('action' => 'admin_privacy_policy',$id));
			} else {
				$this->Session->setFlash(__('Privacy Policy could not be saved. Please, try again.'), 'admin_error');
			}
		} else {
			$this->request->data = $this->Page->read(null, $id);
		}
		
	}


	/**
     *  Sports Setting
     *
     * @param <int> $user_id
     */
	 
	 public function admin_chatSetting() {
		 
		    $this->layout = "admin_dashboard";
			if ($this->request->is('post')) {
				$this->Setting->id = $this->request->data['Setting']['id']  ;
				if ($this->Setting->save($this->request->data)) {
					
					$this->Session->setFlash(__('The setting has been updated'), 'admin_success');
					
				} else {
					$this->Session->setFlash(__('The setting could not be updated. Please, try again.'), 'admin_error');
					
					
				}
			}
			$this->set("settings",$this->Setting->find('all'));
			
	}
	
	/**
     *  Edit Sports Setting
     *
     * @param <int> $user_id
     */
	 
	 public function admin_editSetting($id = null) {
		 
		    $this->layout = "ajax";
			$this->Setting->id = $id  ;
			$this->request->data = $this->Setting->read(null, $id);
	}
	
		 
	 

}

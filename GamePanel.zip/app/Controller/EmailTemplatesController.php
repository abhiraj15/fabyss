<?php
App::uses('AppController', 'Controller');

 /**
 * EmailTemplates Controller
 *
 * @property EmailTemplate $EmailTemplate
 */
 
class EmailTemplatesController extends AppController {

	public $uses = array('EmailTemplate');
    public function beforeFilter() {
        parent::beforeFilter(); 
	}
/**
 * home method
 *
 * @return void
 */
	public function admin_index() {
		$this->layout = "admin_table";
		$this->paginate = array('order'=>array('EmailTemplate.id' => 'DESC'));
		$this->EmailTemplate->recursive = 0;
		$this->set('templates', $this->paginate());
	}
	


/**
 * view method
 *
 * @param string $id
 * @return void
 */
	public function admin_view($id = null) {
		 $this->layout = "ajax";
		$this->EmailTemplate->id = $id;		
		if (!$this->EmailTemplate->exists()) {
			throw new NotFoundException(__('Invalid template'));
		}
		
		$this->set('template', $this->EmailTemplate->read(null, $id));
	}

/**
 * add method
 *
 * @return void
 */
	public function admin_add() {	
		$this->layout = "admin_form";   		
		if ($this->request->is('post')) {
			$this->loadModel('EmailTemplate');			
			$this->EmailTemplate->create();			
			if ($this->EmailTemplate->save($this->request->data,array('validate' => 'only'))) {
				$this->Session->setFlash(__('The template has been saved'), 'admin_success');
				$this->redirect(array('action' => 'admin_index'));
			} else {
				$this->Session->setFlash(__('The template could not be saved. Please, try again.'), 'admin_error');
			}
		}
	
	}

/**
 * edit method
 *
 * @param string $id
 * @return void
 */
	public function admin_edit($id = null) {
		$this->layout = "admin_form";   	
			
		$this->EmailTemplate->id = $id;
		if (!$this->EmailTemplate->exists()) {
			throw new NotFoundException(__('Invalid template'));
		}
		
		if ($this->request->is('post') || $this->request->is('put')) {
			
			if ($this->EmailTemplate->save($this->request->data,array('validate' => 'only'))) {
				$this->Session->setFlash(__('The template has been saved'), 'admin_success');
				$this->redirect(array('action' => 'admin_index'));
			} else {
				$this->Session->setFlash(__('The template could not be saved. Please, try again.'), 'admin_error');
			}
		} else {
			$this->request->data = $this->EmailTemplate->read(null, $id);
			
		}
	}

/**
 * delete method
 *
 * @param string $id
 * @return void
 */
	public function admin_delete($id = null) {
		
		if (!$this->request->is('post')) {
			throw new MethodNotAllowedException();
		}
		
		$this->EmailTemplate->id = $id;
		if (!$this->EmailTemplate->exists()) {
			throw new NotFoundException(__('Invalid template'), 'admin_error');
		}
		if ($this->EmailTemplate->delete()) {
			$this->Session->setFlash(__('EmailTemplate deleted'), 'admin_success');
			$this->redirect(array('action' => 'admin_index'));
		}
		$this->Session->setFlash(__('EmailTemplate was not deleted'), 'admin_error');
		$this->redirect(array('action' => 'admin_index'));
	}
	
 	/**
     *  Active/Inactive Templates
     *
     * @param <int> 
     */
    public function toggle($temp_id, $status) {
        $this->layout = "ajax";
        $status = ($status) ? 0 : 1;
        $this->set(compact('temp_id', 'status'));
        if ($temp_id) {
            $data['EmailTemplate'] = array('id'=>$temp_id, 'status'=>$status);
            $allowed = $this->EmailTemplate->saveAll($data["EmailTemplate"], array('validate'=>false));           
        } 
    }	
	
	
}
